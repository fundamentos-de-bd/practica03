# practica3
Diagrama de caso de uso.
* Edgar Quiroz Castañeda 418003808 
* Silvia Díaz Gomez 408002330
* Narciso Isaac Eugenio Aceves 315581461

## Documentación
## Notas
